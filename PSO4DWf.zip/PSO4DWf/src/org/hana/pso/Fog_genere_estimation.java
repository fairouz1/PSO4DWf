package org.hana.pso;

public class Fog_genere_estimation implements PSOConstants {
	

}
