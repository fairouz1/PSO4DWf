package hana;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.lang.model.element.Element;
import javax.swing.DefaultCellEditor;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.math3.geometry.Vector;

import org.hana.pso.PSODriver_2;
import org.jdom.JDOMException;

import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;

public class Interface_WK_2 extends JFrame{
	private JTable table_1;
	private JPanel contentPane;
	final JTextArea textArea_1 = new JTextArea();
	DefaultMutableTreeNode  racine=  new DefaultMutableTreeNode("Workflow");
	JScrollPane scrollPane;	
	static Interface_WK_2 frame ;
    int click_select=0;
    String chemin="";//---- Le chemin de plan de test choisi
    String log_mapping;
    String SBT;
    String FBT;
    String result_total_cost;
    String task_consolid;
    String result_final;
    static String name_WF_file ;
    static String name_Rule_file;
    private JTable table_2;
    private JTextField textField_deadline;
    int nb_testers;
    String value_deadline;
    String val_deadline;
    String tache_execute;
    String nb_ap_ajout;
    String tache_restante;
    String new_deadline;
    String new_SBT;
    String new_FBT;
   
    String affich;
    String cout_tach_execute;
    String cout_tach_restante;
    String cout_tach_aprs_reaffec;
    String affich_exception;
    String task_adding; 
    String exception;
    int exception__;
    String D_choisi;
    String result_total_cost_reaffect;
    String task_consolid_reaffect;
    double D;
   
	/**
	 * Launch the application.
	 */
  
 

	/**
	 * Create the frame.
	 */
	public Interface_WK_2() {
		setTitle("PSO4DWF");
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1010, 508);
		contentPane = new JPanel();
		//textArea_3.add(contentPane);
		contentPane.setForeground(new Color(0, 0, 128));
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
				
				JLabel ImportWorkflowFile_label = new JLabel("Import Workflow File : ");
				ImportWorkflowFile_label.setForeground(new Color(65, 105, 225));
				ImportWorkflowFile_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				ImportWorkflowFile_label.setBounds(25, 69, 147, 14);
				contentPane.add(ImportWorkflowFile_label);
				
				
				JLabel VM_type_label = new JLabel("VM Types : ");
				VM_type_label.setForeground(new Color(65, 105, 225));
				VM_type_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				VM_type_label.setBounds(30, 109, 76, 14);
				contentPane.add(VM_type_label);

				
				final JLabel deadline_label = new JLabel("Deadline Constraint :");
				deadline_label.setForeground(new Color(65, 105, 225));
				deadline_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				deadline_label.setBounds(25, 215, 147, 14);
				contentPane.add(deadline_label);
				
				
				JLabel SimulationLogresult_label = new JLabel("Simulation log/result :");
				SimulationLogresult_label.setForeground(new Color(65, 105, 225));
				SimulationLogresult_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				SimulationLogresult_label.setBounds(25, 255, 147, 14);
				contentPane.add(SimulationLogresult_label);
				
				


				JLabel cost_of_executed_task_label = new JLabel("Total Cost Of Executed Tasks :");
				cost_of_executed_task_label.setForeground(new Color(128, 0, 128));
				cost_of_executed_task_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				cost_of_executed_task_label.setBounds(10, 815, 194, 15);
				contentPane.add(cost_of_executed_task_label);
				
					//******************************Fin :Les labels***********************//
		
				//********************************************Table des VMs******************************************//


	
				Object[][] data = {
					    {"Small", 1, 2, 0.036},
					    {"Meduim", 1, 4, 0.25},
					    {"Large", 2, 8, 1.266}};
					    
				String [] columnNames = {"Type","Number Of CPU","Memory(GiB)", "Cost($/hour)" };
					

					
		 		
				table_2 = new JTable(data, columnNames);

				JScrollPane scrollPane = new JScrollPane(table_2);
				scrollPane.setBounds(103, 115, 452, 76);
				scrollPane.setColumnHeaderView(table_2.getTableHeader());
			    contentPane.setVisible(true);
				contentPane.add(scrollPane);

				//********************************************Fin : Table VM******************************************//

				//***************************TextField**************************//
				textField_deadline = new JTextField();
				textField_deadline.setBounds(182, 213, 202, 20);
				textField_deadline.setColumns(10);
				contentPane.add(textField_deadline);
				
				
				
				final JTextArea textArea_cost_executed_task = new JTextArea();
				textArea_cost_executed_task.setBounds(198, 811, 76, 19);
				contentPane.add(textArea_cost_executed_task);
				
				
				
				final JTextArea textArea_cost_of_reaffected_task = new JTextArea();
				textArea_cost_of_reaffected_task.setBounds(493, 811, 76, 19);
				contentPane.add(textArea_cost_of_reaffected_task);
				
				
				
				final JTextArea textArea_cost_after_reaffectation = new JTextArea();
				textArea_cost_after_reaffectation.setBounds(807, 811, 76, 19);
				contentPane.add(textArea_cost_after_reaffectation);
				
				//***************************Fin : TextField**************************//

				
				//******************************TextArea***********************//	
				JPanel panel_output_1 = new JPanel();
				panel_output_1.setBackground(new Color(216, 191, 216));
				panel_output_1.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED, new Color(128, 0, 128), new Color(128, 0, 128), new Color(128, 0, 128), new Color(128, 0, 128)), "Result of first execution :", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 0, 128)));
				panel_output_1.setBounds(177, 314, 549, 149);
				contentPane.add(panel_output_1);
				panel_output_1.setLayout(null);
				
				JScrollPane scrollPane_1 = new JScrollPane(textArea_1);
				scrollPane_1.setBounds(22, 22, 503, 103);
				scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				panel_output_1.add(scrollPane_1);

		
				//******************************Fin :TextArea***********************//	

				
				//******************************Les boutons***********************//
				       //-------------Code bouton import WK--------------//

				JButton import_wk_btn = new JButton("Import Workflow File");
				import_wk_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
				import_wk_btn.setBounds(188, 61, 165, 32);
				contentPane.add(import_wk_btn);

				import_wk_btn.addActionListener(new ActionListener() { // action du bouton pour importer fichier xml

					public void actionPerformed(ActionEvent arg0) {
						try {
							import_wk_file() ;
							//---recuperer le nom du fichier xml choisi (voir fonction de import_wk_file() )
							//textArea_1.append(name_WF_file);// pour afficher nom du fichier xml choisi dans console de l'interface

						} catch (JDOMException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}

				});
						
			            //------------------Fin : bouton import WK----------//
				


				      //-------------Code bouton simulation--------------//
				
				JButton simulation_btn = new JButton("Simulate");
				simulation_btn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		//		simulation_btn.setIcon(new ImageIcon(Interface_WK_2.class.getResource("/Icons/build-icon (1).png")));
				simulation_btn.setBounds(563, 255, 86, 38);
				contentPane.add(simulation_btn);
				
				simulation_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						try {
							value_deadline = textField_deadline.getText() +"\n"; // pour afficher valeur de deadline entr�e
						  	System.out.println(value_deadline+"\n");
						  	
						  	
						  	val_deadline =textField_deadline.getText();
						  	int deadline = Integer.parseInt(val_deadline);// faire r�cup�ration de deadline dans pso_driver et puis dans execute de process
						   	// pour afficher resultat d'affichage de PSODriver
						  	PSODriver_2 pso_drive = new PSODriver_2();
						  
						 	name_WF_file = getName_WF_file(); // r�cup�rer le fichier "name_WF_file" 
						 //	name_Rule_file = getName_Rule_file();
						 	
						  	System.out.println("name_WF_file==" +name_WF_file);
						  	
						 
					

							pso_drive.Driver_method(name_WF_file,name_Rule_file,deadline); //recup�rer ce fichier xml avec "name_WF_file", on ajoute deadline pour r�cup�rer deadline de cet input de l'interface
							
							//-----------------------------Pour result de first exceution-------------------------//
							log_mapping = pso_drive.getLog_map()+"\n";// pour avoir les best localit�s des tasks ex�cut�es (de la meilleure solution )
							System.out.println(log_mapping);
							textArea_1.append(log_mapping);
							
							
							SBT = pso_drive.getSE_actuel__()+"\n";// pour avoir les SBT des t�ches ex�cut�es
							textArea_1.append(SBT);
							

							FBT = pso_drive.getFE_actuel__()+"\n";// pour avoir les SBT des t�ches ex�cut�es
							textArea_1.append(FBT);
							
							
							result_total_cost = "Total Cost : "+pso_drive.getResult_total_cost()+" $ \n";// pour avoir cout total
							textArea_1.append(result_total_cost);
						 	 
							 	
							//-----------------------------Fin :Pour result de first exceution-------------------------//




	//-----------------------------Affichage des Cost-------------------------//

						 	cout_tach_execute = pso_drive.getCout_total_Tache_execute()+" $ \n";// pour avoir les co�ts des t�ches ex�cut�es
							//System.out.println(cout_tach_execute);
							textArea_cost_executed_task.append(cout_tach_execute);


	
							//-----------------------------Fin : Affichage des Cost-------------------------//


                            frame.setVisible(true);
						} catch (Exception e) {
							System.err.println("Catch");
						}
					}
				
				

			}	
	      );

				
	             //------------------Fin : Code bouton simulation----------//

				
			      //-------------Code bouton Quit--------------//

				JButton quit_btn = new JButton("Exit");
			//	quit_btn.setIcon(new ImageIcon(Interface_WK_2.class.getResource("/Icons/exit-icon-37972.png")));
				quit_btn.setBounds(659, 255, 97, 38);
				quit_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						System.exit(0);
					}
			});
				
				contentPane.add(quit_btn);
				
							
			      //-------------Fin : Code bouton Quit--------------//

				//******************************Fin : Les boutons***********************//
				
	} // fin constructeur


	 ///****************************Import Fichier de WK.xml*************************//
			private void import_wk_file() throws JDOMException, IOException 
			 {          
		  		// s�lection et lecture du fichier XML
				 JFileChooser jFileChooser1 = new JFileChooser();
				  ExampleFileFilter filter = new ExampleFileFilter();
				 filter.addExtension("XML");
				 jFileChooser1.setFileFilter(filter);
				 jFileChooser1.setDialogTitle("Select");
				if (JFileChooser.APPROVE_OPTION==jFileChooser1.showOpenDialog(this))
				{
					click_select=1;
				    chemin=jFileChooser1.getSelectedFile().getPath(); 
					System.out.println("Chemin : "+ chemin);
					
					File file = new File(chemin);
					 name_WF_file = file.getName();
					System.out.println( name_WF_file); //r�cup�re nom du fichier xml choisi u bouton "import_Wk_file"
		 

		   
		   }
			
			 }
			
			
			///****************************Fin : Import Fichier de WK.xml*************************//

			public String getName_WF_file() {
				return name_WF_file;
			}


			public void setName_WF_file(String name_WF_file) {
				this.name_WF_file = name_WF_file;
			}
			
			
			 
 		//-----------------------Fin: liste des m�thodes-----------------------//
			
			  
			public String getName_Rule_file() {
				return name_Rule_file;
			}
 
			public void setName_Rule_file(String name_Rule_file) {
				this.name_Rule_file = name_Rule_file;
			}
 		public static void main(String[] args) {
				frame = new Interface_WK_2();
				frame.setUndecorated(true);
				frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
				frame.setVisible(true);

						
			}
 }// fin class

