package hana;

public class ColumnNames {

	
	private String Type;
	private Number CPU;
	private Number Memory;
	private Double Cost;
	public ColumnNames(String type, Number cPU, Number memory, Double cost) {
		super();
		Type = type;
		CPU = cPU;
		Memory = memory;
		Cost = cost;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public Number getCPU() {
		return CPU;
	}
	public void setCPU(Number cPU) {
		CPU = cPU;
	}
	public Number getMemory() {
		return Memory;
	}
	public void setMemory(Number memory) {
		Memory = memory;
	}
	public Double getCost() {
		return Cost;
	}
	public void setCost(Double cost) {
		Cost = cost;
	}
	
	
	
	
	
}
