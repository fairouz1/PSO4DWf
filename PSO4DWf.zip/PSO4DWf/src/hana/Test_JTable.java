package hana;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.lang.model.element.Element;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.math3.geometry.Vector;
import org.hana.pso.PSODriver;
import org.jdom.JDOMException;

import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test_JTable extends JFrame{

	private JTable table_1;
	private JPanel contentPane;
	DefaultMutableTreeNode  racine=  new DefaultMutableTreeNode("Workflow");
	JScrollPane scrollPane;	
	static Test_JTable frame ;
    int click_select=0;
    String chemin="";//---- Le chemin de plan de test choisi
    String log_mapping;
    String result_total_cost;
    String task_consolid;
    String result_final;
    static String name_WF_file ;
    String name_Rule_file;
    private JTable table_2;
    private JTextField textField_deadline;
    int nb_testers;
    String value_deadline;
   double D;
   
	/**
	 * Launch the application.
	 */
  
 

	/**
	 * Create the frame.
	 */
	public Test_JTable() {
		setTitle("Interface-Workflow");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 658, 700);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 128));
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		//contentPane.setLayout(null);
		
		

				
				
				//********************************************Table VM******************************************//

				//JPanel panel = new JPanel();
				//panel.setLayout(new BorderLayout());
				
				Object[][] data = {
					    {"Small", 1, 2, 0.036},
					    {"Meduim", 1, 4, 0.133},
					    {"Large", 2, 8, 0.266}};
					    
				String [] columnNames = {"Type","Number Of CPU","Memory(GiB)", "Cost($/hour)" };
					

					
			  // DefaultTableModel model = new DefaultTableModel(data, columnNames);
				       
				
				table_2 = new JTable(data, columnNames);

				//JScrollPane scrollPane = new JScrollPane(table_2);
				//scrollPane.setColumnHeaderView(table_2.getTableHeader());
				//contentPane.add(scrollPane);
				
			//	scrollPane.setViewportView(table_2);
				//table_2.setFillsViewportHeight(true);
				//scrollPane.add(table_2);
				table_2.setBounds(105, 167, 262, 48);

				
				contentPane.add(new JScrollPane(table_2), BorderLayout.CENTER);
				
				JPanel boutons = new JPanel();
				 
		      
				 // pack();
			//	JTableHeader header = table_2.getTableHeader();
			//	contentPane.add(header, BorderLayout.NORTH);
			//	contentPane.add(table_2, BorderLayout.CENTER);
				
			//	contentPane.add(table_2.getTableHeader(),BorderLayout.NORTH);
			//    contentPane.add(scrollPane);
			 // contentPane.add(scrollPane);
			 // contentPane.setVisible(true);
				//contentPane.add(scrollPane);				

				//********************************************Fin :Table VM*************************************//
			    
				
	}
			
			  
			public static void main(String[] args) {
				frame = new Test_JTable();
				//frame.setUndecorated(true);// si j'enl�ve �a il m'affiche decoration de l'interface
				frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
				frame.setVisible(true);

						
			}
 }// fin class

