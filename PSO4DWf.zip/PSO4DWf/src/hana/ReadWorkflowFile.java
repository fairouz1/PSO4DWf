package hana;

import java.io.File;
import java.io.IOException;

import javax.lang.model.element.Element;
import javax.swing.text.Document;

import org.jdom.JDOMException;
import org.jdom.input.DOMBuilder;
import org.jdom.input.SAXBuilder;
import org.jdom.*; 
import org.jdom.output.*;
import org.jdom.input.*;

import java.io.*;
import java.util.List;
import java.util.Vector;
import java.util.List.*; 

public class ReadWorkflowFile {

	
	DOMBuilder builder;
    Document doc ;
    Element root;

    public  Element[] enfant(Element e)
	{   	System.out.println("@@@@@@@@@@@@@@@@enfant(Element e)@@@@@@@@@@@@@@@@");
	
			java.util.List l=(List) e.getEnclosingElement();
			Object fils_objet[]=l.toArray();
			Element fils[]=new Element [fils_objet.length];
			for(int i=0;i<fils_objet.length;i++)
				fils[i]=(Element)fils_objet[i];
			return fils;
	
	}//Fin enfant
	

	public ReadWorkflowFile(String chemin) throws JDOMException, IOException
	{
		System.out.println("*************Chemin***********"+ chemin);
		builder = new DOMBuilder();
		 SAXBuilder sxb = new SAXBuilder();
		doc = (Document) sxb.build(new File(chemin));
		
		root = (Element) doc.getDefaultRootElement();
		System.out.println(root.getSimpleName());
	}
	
	public int read_size() throws JDOMException
	{
	Element parent []=this.enfant(root);
		int size=parent.length;
		System.out.println("size="+size);
		return size;
	}
	
	public Vector<String> Read_TestComponents() throws JDOMException
	{
		
		Element parent []=this.enfant(root);
		int size=parent.length;
		Vector <String> testComponents= new Vector<String>();
		for(int i=0;i<size;i++)
		{
			java.util.List ListAttribut =(List) ((javax.swing.text.Element) parent[i]).getAttributes();
			Object Attribut_objet[]=ListAttribut.toArray();
			Attribute  Attribut[]=new Attribute  [Attribut_objet.length];
			for(int j=0;j<Attribut_objet.length;j++)
				   Attribut[j]=(Attribute)Attribut_objet[j];
			testComponents.addElement(Attribut[1].getValue());  //- j'ai modifi� 1 en 0=> affiche componentTester
		}
		for (int i=0; i<testComponents.size();i++)
			System.out.println("TC= "+testComponents.get(i).toString());
		return testComponents;
	}
}
