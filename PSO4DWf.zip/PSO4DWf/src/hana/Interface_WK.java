package hana;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.lang.model.element.Element;
import javax.swing.DefaultCellEditor;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.math3.geometry.Vector;
import org.hana.pso.PSODriver_2;
import org.jdom.JDOMException;

import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class Interface_WK extends JFrame{
	final JTextArea textArea_1 = new JTextArea();
	private JTable table_1;
	private JPanel contentPane;
	DefaultMutableTreeNode  racine=  new DefaultMutableTreeNode("Workflow");
	JScrollPane scrollPane;	
	static Interface_WK frame ;
    int click_select=0;
    String chemin="";//---- Le chemin de plan de test choisi
    String log_mapping;
    String SBT;
    String FBT;
    String result_total_cost;
    String task_consolid;
    String result_final;
    static String name_WF_file ;
    static String name_Rule_file;
    private JTable table_2;
    private JTextField textField_deadline;
    int nb_testers;
    String value_deadline;
    String val_deadline;
    String tache_execute;
    String nb_ap_ajout;
    String tache_restante;
    String new_deadline;
    String new_SBT;
    String new_FBT;
    String Log_map_reaff;
    String affich;
    String cout_tach_execute;
    String cout_tach_restante;
    String cout_tach_aprs_reaffec;
    String affich_no_exception;
    String task_adding; 
    String exception;
    int exception__;
    double D;
   
	/**
	 * Launch the application.
	 */
  
 

	/**
	 * Create the frame.
	 */
	public Interface_WK() {
		setTitle("Interface-Workflow");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 737, 1099);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 128));
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		//contentPane.setLayout(null);
		
		
		
		//******************************Les labels***********************//
				JLabel Interface_label = new JLabel("Interface - Workflow");
				Interface_label.setForeground(new Color(184, 134, 11));
				Interface_label.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 22));
				Interface_label.setBounds(178, 5, 244, 42);
				contentPane.add(Interface_label);

				
				JLabel VM_type_label = new JLabel("VM Types : ");
				VM_type_label.setForeground(new Color(65, 105, 225));
				VM_type_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				VM_type_label.setBounds(25, 206, 76, 14);
				contentPane.add(VM_type_label);

				
				final JLabel deadline_label = new JLabel("Deadline Constraint :");
				deadline_label.setForeground(new Color(65, 105, 225));
				deadline_label.setFont(new Font("Tahoma", Font.BOLD, 12));
				deadline_label.setBounds(25, 376, 147, 14);
				contentPane.add(deadline_label);

				
	//******************************Fin :Les labels***********************//
		
				//********************************************Table VM******************************************//

				//JPanel panel = new JPanel();
				//panel.setLayout(new BorderLayout());
				
				Object[][] data = {
					    {"Small", 1, 2, 0.036},
					    {"Meduim", 1, 4, 0.133},
					    {"Large", 2, 8, 0.266}};
					    
				String [] columnNames = {"Type","Number Of CPU","Memory(GiB)", "Cost($/hour)" };
					

					
			  // DefaultTableModel model = new DefaultTableModel(data, columnNames);
				       
				
				table_2 = new JTable(data, columnNames);

				JScrollPane scrollPane = new JScrollPane(table_2);
				scrollPane.setBounds(104, 228, 452, 76);
				scrollPane.setColumnHeaderView(table_2.getTableHeader());
			    contentPane.setVisible(true);
				contentPane.add(scrollPane);

				//********************************************Fin : Table VM******************************************//

				//***************************TextField**************************//
				textField_deadline = new JTextField();
				textField_deadline.setBounds(191, 373, 202, 20);
				textField_deadline.setColumns(10);
				contentPane.add(textField_deadline);

				//************************Fin : TextField**********************//
				
				
				//******************************TextArea***********************//		

				JPanel panel_output = new JPanel();
				panel_output.setBackground(new Color(191, 205, 219));
				panel_output.setBorder(new TitledBorder(new BevelBorder(BevelBorder.RAISED, new Color(191, 205, 219), new Color(191, 205, 219), new Color(191, 205, 219), new Color(191, 205, 219)), "Simulation log/result : ", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(65, 105, 225)));
				panel_output.setBounds(25, 421, 592, 247);
				contentPane.add(panel_output);
				panel_output.setLayout(null);
				
				JScrollPane scrollPane_1 = new JScrollPane(textArea_1);
				scrollPane_1.setBounds(16, 30, 552, 200);
				//scrollPane_1.setRowHeaderView(textArea_1);
				scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

				panel_output.add(scrollPane_1);
				
				//******************************Fin :TextArea***********************//	
				
				
				//******************************Les boutons***********************//
				       //-------------Code bouton import WK--------------//

				JButton import_wk_btn = new JButton("Import Workflow File");
				import_wk_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
				import_wk_btn.setBounds(191, 70, 165, 32);
				contentPane.add(import_wk_btn);

				import_wk_btn.addActionListener(new ActionListener() { // action du bouton pour importer fichier xml

					public void actionPerformed(ActionEvent arg0) {
						try {
							import_wk_file() ;
							//---recuperer le nom du fichier xml choisi (voir fonction de import_wk_file() )
							textArea_1.append(name_WF_file);// pour afficher nom du fichier xml choisi dans console de l'interface

						} catch (JDOMException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}

				});
						
			            //------------------Fin : bouton import WK----------//
				
				
			           //-------------Code bouton import Rule--------------//

				JButton import_rule_btn = new JButton("Import Rule File");
				import_rule_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
				import_rule_btn.setBounds(191, 130, 165, 32);
				contentPane.add(import_rule_btn);

				import_rule_btn.addActionListener(new ActionListener() { // action du bouton pour importer fichier xml

					public void actionPerformed(ActionEvent arg0) {
						try {
							import_rule_file() ;
							//---recuperer le nom du fichier xml choisi (voir fonction de import_Rule_file() )
							textArea_1.append(name_Rule_file);// pour afficher nom du fichier xml choisi dans console de l'interface

						} catch (JDOMException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}

				});
	            
				      //------------------Fin : bouton import Rule----------//

				
			 
				      //-------------Code bouton simulation--------------//
				
				JButton simulation_btn = new JButton("");
				simulation_btn.setFont(new Font("Tahoma", Font.PLAIN, 13));
				simulation_btn.setIcon(new ImageIcon(Interface_WK.class.getResource("/Icons/build-icon (1).png")));
				simulation_btn.setBounds(136, 693, 86, 38);
				contentPane.add(simulation_btn);
				
				simulation_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						try {
							value_deadline = "\n Deadline Choisi == " +textField_deadline.getText()+"\n";// pour afficher valeur de deadline entr�e
						  	System.out.println(value_deadline+"\n");
						  	textArea_1.append(value_deadline); //pour afficher la valeur de deadline dans console de l'interface
						  	
						  	val_deadline =textField_deadline.getText();
						  	int deadline = Integer.parseInt(val_deadline);// faire r�cup�ration de deadline dans pso_driver et puis dans execute de process
						  	//System.out.println("deadline ="+deadline);
						  	System.out.println("=========== Hanouna========="); // pour afficher resultat d'affichage de PSODriver
						  	PSODriver_2 pso_drive = new PSODriver_2();
						  
						 	name_WF_file = getName_WF_file(); // r�cup�rer le fichier "name_WF_file" 
						 	name_Rule_file = getName_Rule_file();
						 	
						  	System.out.println("nounou" +name_WF_file);
						  	System.out.println("nounou_2" +name_Rule_file);
						  	
						  	if (name_Rule_file.isEmpty()) {
								
								pso_drive.Driver_method(name_WF_file,name_Rule_file,deadline); 
							}
						  	
					

							pso_drive.Driver_method(name_WF_file,name_Rule_file,deadline); //recup�rer ce fichier xml avec "name_WF_file", on ajoute deadline pour r�cup�rer deadline de cet input de l'interface
							
						  	exception ="Num d'exception = "+pso_drive.getException()+"\n";
							textArea_1.append(exception);
							
							exception__ = pso_drive.getException();
							if (exception__ ==0){ // on affiche ce message si exception =0
							affich_no_exception = "****No Exception Found****\n";
							textArea_1.append(affich_no_exception);
							}// fin "if"
							
							log_mapping = pso_drive.getLog_map()+"\n";// pour avoir les best localit�s des tasks ex�cut�es (de la meilleure solution )
							System.out.println(log_mapping);
							textArea_1.append(log_mapping);
							
							
							SBT = pso_drive.getSE_actuel__()+"\n";// pour avoir les SBT des t�ches ex�cut�es
							textArea_1.append(SBT);
							

							FBT = pso_drive.getFE_actuel__()+"\n";// pour avoir les SBT des t�ches ex�cut�es
							textArea_1.append(FBT);
							
							
							result_total_cost = "Total Cost Before Consolidation : "+pso_drive.getResult_total_cost()+" $ \n";// pour avoir cout total avant consolidation affich�
							textArea_1.append(result_total_cost);
						 	 
						 	task_consolid = pso_drive.getTask_consolid()+"\n";// pour avoir l'affichage de la tache consolid�e
						 	textArea_1.append(task_consolid);
						 	
						 	result_final = "Total Cost After Consolidation : "+pso_drive.getResult_final()+" $ \n"; // pour avoir resultat final apr�s consolidation affich� dans console
						 	textArea_1.append(result_final);
						 	
						 	tache_execute ="Executed Tasks == "+ pso_drive.getTache_execute() +"\n";// pour avoir les t�ches qui sint ex�cut�es
						 	textArea_1.append(tache_execute);

						 	task_adding = "Number Of added Tasks == "+pso_drive.getTask_adding()+"\n"; // pour avoir nb de t�ches ajout�es
						 	textArea_1.append(task_adding);

						 	nb_ap_ajout = "Number Of Tasks after add == "+pso_drive.getNb_ap_ajout() +"\n";//pour avoir nb de t�ches apr�s ajout
						 	textArea_1.append(nb_ap_ajout);
						 	
						 	tache_restante = "Tasks to reaffect : "+pso_drive.getTache_restante()+"\n";
						 	textArea_1.append(tache_restante);
						 	
						 	
						 	new_deadline = "New Deadline Value == "+pso_drive.getNew_D()+"\n"; //pour avoir new_deadline des t�ches � reaffecter
						 	textArea_1.append(new_deadline);
						 	
						 	
						 	affich = "***************Localities Of Reaffected Tasks****************\n";
						 	textArea_1.append(affich);

							Log_map_reaff = pso_drive.getLog_map_reaff()+"\n";// pour avoir les best localit�s des tasks � reaffecter (de la meilleure solution )
							System.out.println(Log_map_reaff);
						 	textArea_1.append(Log_map_reaff);
						 	
						 	
						 	new_SBT = pso_drive.getNew_SBT__()+ "\n";// pour avoir les SBT des t�ches � reaffecter
						 	textArea_1.append(new_SBT);

						 	new_FBT = pso_drive.getNew_FBT__()+ "\n";// pour avoir les FBT des t�ches � reaffecter
						 	textArea_1.append(new_FBT);
						 	
						 						 	
						 	cout_tach_execute = "Total Cost of Executed Tasks == "+pso_drive.getCout_total_Tache_execute()+" $ \n";// pour avoir les co�ts des t�ches ex�cut�es
							System.out.println(cout_tach_execute);
						 	textArea_1.append(cout_tach_execute);

                            cout_tach_restante = "Total Cost of Rest tasks == "+pso_drive.getCout_total_Tache_restante()+" $ \n";// pour avoir les co�ts des t�ches � reaffecter (restantes)
							System.out.println(cout_tach_restante);
                            textArea_1.append(cout_tach_restante);
						 	
						 	cout_tach_aprs_reaffec = "Total Cost After Reaffectation == "+pso_drive.getCout_total_apr�s_reaffectation()+" $ \n";// pour avoir le co�t totla "somme :" (des t�ches reaffecter + ex�cut�es)
							System.out.println(cout_tach_aprs_reaffec);
						 	textArea_1.append(cout_tach_aprs_reaffec);

                            frame.setVisible(true);
						} catch (Exception e) {
							System.err.println("Catch");
						}
					}
				
				
				//**************************** Lecture du fichier import� dans partie d'affichage ****************************//
//			  	public void read_log_test() throws IOException{
//				String thisLine ;
//				String [] fullText = new String [10];
//				int counter = 0;
//				FileInputStream fis = new FileInputStream ("D:\\test_file.txt");
//				DataInputStream myInput = new DataInputStream ( fis );
//				while (( thisLine = myInput . readLine ()) != null ) {
//					System . out . println ("My Output : "+ thisLine );
//					log_testCase=log_testCase+"\n"+thisLine;
//					counter ++;
//					fullText [ counter ] = thisLine ;
//				}
//				//System.out.println("===========AAAAAA Fin lire fichier log AAAAAA =========");
//				//System.out.println("===========log_testCase @@@@@ ========="+ log_testCase);
//				
//			  	}	
			}	
	      );

				
	             //------------------Fin : Code bouton simulation----------//

				
			      //-------------Code bouton Quit--------------//

				JButton quit_btn = new JButton("");
				quit_btn.setIcon(new ImageIcon(Interface_WK.class.getResource("/Icons/exit-icon-37972.png")));
				quit_btn.setBounds(343, 693, 97, 38);
				quit_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						System.exit(0);
					}
			});
				
				contentPane.add(quit_btn);
				
						

				//******************************Fin : Les boutons***********************//
				
	} // fin constructeur
	


	



//	public void setD(double d) {
//		D  = d;
//		
//	}
//
//	public double getD() {
//		value_deadline =textField_deadline.getText()+"\n";
//		System.out.println("value_deadline "+value_deadline );
//		D = Integer.parseInt(value_deadline);
//		System.out.println("D"+D);
//		return D;
//
//}

			//---------------------------------Liste des m�thodes appel�es--------------------//
	///****************************Import Fichier de WK.xml*************************//
			private void import_wk_file() throws JDOMException, IOException 
			 {          
		  		// s�lection et lecture du fichier XML
				 JFileChooser jFileChooser1 = new JFileChooser();
				  ExampleFileFilter filter = new ExampleFileFilter();
				 filter.addExtension("XML");
				 jFileChooser1.setFileFilter(filter);
				 jFileChooser1.setDialogTitle("Select");
				if (JFileChooser.APPROVE_OPTION==jFileChooser1.showOpenDialog(this))
				{
					click_select=1;
				    chemin=jFileChooser1.getSelectedFile().getPath(); 
					System.out.println("Chemin : "+ chemin);
					
					File file = new File(chemin);
					 name_WF_file = file.getName();
					System.out.println( name_WF_file); //r�cup�re nom du fichier xml choisi u bouton "import_Wk_file"
					//name_WF_file = chemin.getN
					//System.out.println("name_WF_file "+name_WF_file);
					//ReadWorkflowFile tp=new ReadWorkflowFile(chemin);
					//Vector testers =  (Vector) tp.Read_TestComponents();
					//nb_testers=tp.read_size();
					//System.out.println("nb_testers "+nb_testers);
					//construction(racine, testers);


		   
		   }
			
			 }
			
			
			///****************************Fin : Import Fichier de WK.xml*************************//

			public String getName_WF_file() {
				return name_WF_file;
			}


			public void setName_WF_file(String name_WF_file) {
				this.name_WF_file = name_WF_file;
			}
			
			
			///**************************** Import Fichier de Rule.xml*************************//

			private void import_rule_file() throws JDOMException, IOException  // m�thode pour importer fichier des rules
			 {          
		  		// s�lection et lecture du fichier XML
				 JFileChooser jFileChooser1 = new JFileChooser();
				  ExampleFileFilter filter = new ExampleFileFilter();
				 filter.addExtension("XML");
				 jFileChooser1.setFileFilter(filter);
				 jFileChooser1.setDialogTitle("Select");
				if (JFileChooser.APPROVE_OPTION==jFileChooser1.showOpenDialog(this))
				{
					click_select=1;
				    chemin=jFileChooser1.getSelectedFile().getPath(); 
					System.out.println("Chemin : "+ chemin);
					
					File file = new File(chemin);
					 name_Rule_file = file.getName();
					System.out.println(name_Rule_file); //r�cup�re nom du fichier xml choisi du bouton "import_rule_file"
				

		 		}
		   
		   }
			
			///****************************Fin : Import Fichier de Rule.xml*************************//

			

			//-----------------------Fin: liste des m�thodes-----------------------//
			
			  
			public String getName_Rule_file() {
				return name_Rule_file;
			}







			public void setName_Rule_file(String name_Rule_file) {
				this.name_Rule_file = name_Rule_file;
			}







			public static void main(String[] args) {
				frame = new Interface_WK();
				frame.setUndecorated(true);
				frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
				frame.setVisible(true);

						
			}
 }// fin class

