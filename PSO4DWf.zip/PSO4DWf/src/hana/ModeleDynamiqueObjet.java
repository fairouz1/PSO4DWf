package hana;

import java.awt.List;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class ModeleDynamiqueObjet extends AbstractTableModel {
    private final ArrayList<ColumnNames> vms = new ArrayList<ColumnNames>();
 
    private final String[] entetes = {"Type","Number Of CPU","Memory(GiB)", "Cost($/hour)" };
 
    public ModeleDynamiqueObjet() {
        super();
 
        vms.add(new ColumnNames( "Small", 1, 2, 0.036));
        vms.add(new ColumnNames("Meduim", 1, 4, 0.133));
        vms.add(new ColumnNames("Large", 2, 8, 0.266));
        
    }
 
    public int getRowCount() {
        return vms.size();
    }
 
    public int getColumnCount() {
        return entetes.length;
    }
 
    public String getColumnName(int columnIndex) {
        return entetes[columnIndex];
    }
 
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return vms.get(rowIndex).getType();
            case 1:
                return vms.get(rowIndex).getCPU();
            case 2:
                return vms.get(rowIndex).getMemory();
            case 3:
                return vms.get(rowIndex).getCost();
            
            default:
                return null; //Ne devrait jamais arriver
        }
    }
 
    public void addColumnNames(ColumnNames c) {
    	vms.add(c);
 
        fireTableRowsInserted(vms.size() -1, vms.size() -1);
    }
 
    public void removeColumnNames(int rowIndex) {
    	vms.remove(rowIndex);
 
        fireTableRowsDeleted(rowIndex, rowIndex);
    }
}
